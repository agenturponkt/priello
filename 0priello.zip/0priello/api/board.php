<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

// === Optional simple protection ===
// Set a long random key here AND in the HTML files (API_KEY). Leave empty to disable.
$API_KEY = '';
// Allow key via header OR query param (useful for one-time maintenance calls in a browser)
$clientKey = $_SERVER['HTTP_X_API_KEY'] ?? ($_GET['key'] ?? '');
if ($API_KEY !== '' && $clientKey !== $API_KEY) {
  http_response_code(401);
  echo json_encode(['error' => 'unauthorized']);
  exit;
}

// Auto-delete TTL for done cards
const DONE_TTL_SECONDS = 7 * 24 * 60 * 60;

$dir = __DIR__ . '/data';
if (!is_dir($dir)) { mkdir($dir, 0755, true); }
$dbPath = $dir . '/board.sqlite';

try {
  $db = new PDO('sqlite:' . $dbPath);
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $db->exec("CREATE TABLE IF NOT EXISTS board_state (
    id TEXT PRIMARY KEY,
    state_json TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
  )");

  function parseTsToSeconds($v): ?int {
    if ($v === null) return null;

    if (is_int($v)) {
      // Heuristic: ms vs seconds
      return ($v > 2000000000) ? intdiv($v, 1000) : $v;
    }
    if (is_float($v)) {
      $iv = (int)$v;
      return ($iv > 2000000000) ? intdiv($iv, 1000) : $iv;
    }
    if (is_string($v)) {
      // numeric string?
      if (preg_match('/^\d+$/', $v)) {
        $iv = (int)$v;
        return ($iv > 2000000000) ? intdiv($iv, 1000) : $iv;
      }
      $ts = strtotime($v);
      if ($ts !== false) return $ts;
    }
    return null;
  }

  function persistState(PDO $db, array $state, int $version): void {
    $payload = [
      'cards' => $state['cards'] ?? [],
      'labels' => $state['labels'] ?? [],
      'machines' => $state['machines'] ?? [],
    ];
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($json === false) throw new RuntimeException('json_encode_failed');

    $stmt = $db->prepare("INSERT INTO board_state(id, state_json, version, updated_at)
      VALUES('default', :json, :version, :ts)
      ON CONFLICT(id) DO UPDATE SET state_json=:json, version=:version, updated_at=:ts");
    $stmt->execute([
      ':json' => $json,
      ':version' => $version,
      ':ts' => gmdate('c'),
    ]);
  }

  /**
   * Normalisiert Karten (defaults) und repariert doppelte/fehlende IDs.
   * Optional: löscht Karten nach Auftragsnummer (ordersToDelete).
   *
   * Returns: [state, changed, stats]
   */
  function normalizeState(array $state, array $ordersToDelete, int $nowMs): array {
    $changed = false;
    $stats = [
      'removedByOrder' => 0,
      'fixedDuplicateIds' => 0,
      'fixedMissingIds' => 0,
      'fixedFields' => 0,
    ];

    if (!isset($state['cards']) || !is_array($state['cards'])) { $state['cards'] = []; $changed = true; }

    $ordersSet = [];
    foreach ($ordersToDelete as $o) {
      $o = trim((string)$o);
      if ($o !== '') $ordersSet[$o] = true;
    }

    // First pass: filter invalid cards + compute max card_N
    $cards = [];
    $maxNum = 0;
    foreach ($state['cards'] as $c) {
      if (!is_array($c)) { $changed = true; continue; }

      $order = (string)($c['auftragsnummer'] ?? '');
      if ($order !== '' && isset($ordersSet[$order])) {
        $stats['removedByOrder']++;
        $changed = true;
        continue;
      }

      $id = (string)($c['id'] ?? '');
      if ($id !== '' && preg_match('/^card_(\d+)$/', $id, $m)) {
        $n = (int)$m[1];
        if ($n > $maxNum) $maxNum = $n;
      }
      $cards[] = $c;
    }

    // Second pass: ensure unique IDs + defaults
    $seen = [];
    foreach ($cards as $i => $c) {
      $id = (string)($c['id'] ?? '');

      if ($id === '') {
        $maxNum++;
        $id = 'card_' . $maxNum;
        $c['id'] = $id;
        $stats['fixedMissingIds']++;
        $changed = true;
      } elseif (isset($seen[$id])) {
        $maxNum++;
        $newId = 'card_' . $maxNum;
        $c['id'] = $newId;
        $stats['fixedDuplicateIds']++;
        $changed = true;
      }
      $seen[$c['id']] = true;

      // Defaults / schema repair
      if (!isset($c['labels']) || !is_array($c['labels'])) { $c['labels'] = []; $stats['fixedFields']++; $changed = true; }
      if (!isset($c['status']) || !in_array((string)$c['status'], ['open','shipping','done'], true)) { $c['status'] = 'open'; $stats['fixedFields']++; $changed = true; }
      if (!isset($c['createdAt']) || !is_numeric($c['createdAt'])) { $c['createdAt'] = $nowMs; $stats['fixedFields']++; $changed = true; }
      if (!isset($c['primaryColor']) || !is_string($c['primaryColor'])) { $c['primaryColor'] = ''; $stats['fixedFields']++; $changed = true; }

      if ($c['status'] === 'done' && (!isset($c['doneAt']) || !is_numeric($c['doneAt']))) {
        $c['doneAt'] = $nowMs;
        $stats['fixedFields']++;
        $changed = true;
      }

      $cards[$i] = $c;
    }

    $state['cards'] = $cards;
    return [$state, $changed, $stats];
  }

  /**
   * Entfernt DONE Karten, wenn doneAt älter als TTL ist.
   * Wenn doneAt fehlt/unlesbar ist, wird doneAt auf "jetzt" gesetzt,
   * damit die Karte erst ab jetzt nach 7 Tagen gelöscht wird.
   */
  function cleanupDoneCards(array $cards, int $nowSec, bool &$changed): array {
    $out = [];
    foreach ($cards as $c) {
      if (!is_array($c)) { $changed = true; continue; }
      $status = (string)($c['status'] ?? 'open');
      if ($status !== 'done') { $out[] = $c; continue; }

      $doneAt = $c['doneAt'] ?? null;
      $doneSec = parseTsToSeconds($doneAt);
      if ($doneSec === null) {
        $c['doneAt'] = $nowSec * 1000;
        $changed = true;
        $out[] = $c;
        continue;
      }

      if (($nowSec - $doneSec) >= DONE_TTL_SECONDS) {
        $changed = true;
        continue; // drop card
      }
      $out[] = $c;
    }
    return $out;
  }

  function getBoard(PDO $db): array {
    $stmt = $db->prepare("SELECT state_json, version FROM board_state WHERE id='default' LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    $state = [
      'cards' => [],
      'labels' => [],
      'machines' => [],
      'version' => 0,
    ];

    if ($row) {
      $decoded = json_decode((string)$row['state_json'], true);
      if (is_array($decoded)) $state = array_merge($state, $decoded);
      $state['version'] = (int)$row['version'];
    }

    // defaults for top-level
    if (!isset($state['cards']) || !is_array($state['cards'])) $state['cards'] = [];
    if (!isset($state['labels']) || !is_array($state['labels'])) $state['labels'] = [];
    if (!isset($state['machines']) || !is_array($state['machines'])) $state['machines'] = [];

    $nowSec = time();
    $nowMs = $nowSec * 1000;

    $changed = false;
    [$state, $normChanged, $stats] = normalizeState($state, [], $nowMs);
    if ($normChanged) $changed = true;

    $state['cards'] = cleanupDoneCards((array)$state['cards'], $nowSec, $changed);

    if ($changed && $row) {
      $nextVersion = ((int)$row['version']) + 1;
      persistState($db, $state, $nextVersion);
      $state['version'] = $nextVersion;
      $state['_repair'] = $stats;
    }

    if ($changed && !$row) {
      // initialize table with normalized state
      persistState($db, $state, 1);
      $state['version'] = 1;
      $state['_repair'] = $stats;
    }

    return $state;
  }

  function saveBoard(PDO $db, array $incoming): array {
    $current = getBoard($db);
    $nextVersion = ((int)($current['version'] ?? 0)) + 1;

    $state = [
      'cards' => $incoming['cards'] ?? [],
      'labels' => $incoming['labels'] ?? [],
      'machines' => $incoming['machines'] ?? [],
    ];

    $nowSec = time();
    $nowMs = $nowSec * 1000;

    $changed = false;
    [$state, $normChanged, $stats] = normalizeState($state, [], $nowMs);
    if ($normChanged) $changed = true;

    $state['cards'] = cleanupDoneCards((array)$state['cards'], $nowSec, $changed);

    persistState($db, $state, $nextVersion);
    $state['version'] = $nextVersion;
    if ($changed) $state['_repair'] = $stats;
    return $state;
  }

  // --- Request handling ---
  $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

  if ($method === 'GET') {
    // One-time maintenance: delete by order numbers + repair ids
    if (isset($_GET['repair']) && (string)$_GET['repair'] === '1') {
      $stmt = $db->prepare("SELECT state_json, version FROM board_state WHERE id='default' LIMIT 1");
      $stmt->execute();
      $row = $stmt->fetch(PDO::FETCH_ASSOC);

      $state = [
        'cards' => [],
        'labels' => [],
        'machines' => [],
      ];
      $version = 0;
      if ($row) {
        $decoded = json_decode((string)$row['state_json'], true);
        if (is_array($decoded)) $state = array_merge($state, $decoded);
        $version = (int)$row['version'];
      }

      $orders = [];
      if (isset($_GET['orders'])) {
        $orders = array_filter(array_map('trim', explode(',', (string)$_GET['orders'])));
      }

      $nowSec = time();
      $nowMs = $nowSec * 1000;

      $changed = false;
      [$state, $normChanged, $stats] = normalizeState($state, $orders, $nowMs);
      if ($normChanged) $changed = true;

      $state['cards'] = cleanupDoneCards((array)$state['cards'], $nowSec, $changed);

      if ($changed) {
        $nextVersion = $version + 1;
        persistState($db, $state, $nextVersion);
        echo json_encode([
          'ok' => true,
          'version' => $nextVersion,
          'stats' => $stats,
          'message' => 'repair_applied'
        ], JSON_UNESCAPED_UNICODE);
      } else {
        echo json_encode([
          'ok' => true,
          'version' => $version,
          'stats' => $stats,
          'message' => 'no_changes'
        ], JSON_UNESCAPED_UNICODE);
      }
      exit;
    }

    echo json_encode(getBoard($db), JSON_UNESCAPED_UNICODE);
    exit;
  }

  if ($method === 'PUT') {
    $raw = file_get_contents('php://input');
    $incoming = json_decode($raw ?? '', true);
    if (!is_array($incoming)) {
      http_response_code(400);
      echo json_encode(['error' => 'invalid_json']);
      exit;
    }
    echo json_encode(saveBoard($db, $incoming), JSON_UNESCAPED_UNICODE);
    exit;
  }

  http_response_code(405);
  echo json_encode(['error' => 'method_not_allowed']);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error' => 'server_error', 'message' => $e->getMessage()]);
}
