# PriEllo Deployment (priello.printex.ch)

## Upload
Upload the contents of this folder to the webroot of `https://priello.printex.ch/`

Required paths:
- `/prielo-board.html`
- `/prielo-calendar.html`
- `/prielo-maschinen-uebersicht.html`
- `/api/board.php`
- `/api/data/` (writable by PHP, contains `board.sqlite`)

## Permissions
Make sure the folder `api/data/` is writable by PHP (often 755 is fine, some hosters require 775).

## Optional access protection
Open `/api/board.php` and set:
- `$API_KEY = '...';`

Then open all 3 HTML files and set:
- `const API_KEY = '...';`

(Leave it empty to disable.)
