<?php header("Location: /prielo-board.html", true, 302); exit; ?>
